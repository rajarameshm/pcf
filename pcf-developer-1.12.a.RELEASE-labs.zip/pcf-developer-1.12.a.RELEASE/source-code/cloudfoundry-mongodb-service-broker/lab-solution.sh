mvn clean package -DskipTests

cf push mongodb-service-broker -p target/cloudfoundry-service-broker-0.0.1-SNAPSHOT.jar -m 768M -n mongodb-service-broker-jl --no-start

cf set-env mongodb-service-broker SERVICE_ID mongodb-service-broker-jl

cf set-env mongodb-service-broker SERVICE_NAME MongoDB-jl

cf set-env mongodb-service-broker PLAN_ID mongo-plan-jl

cf set-env mongodb-service-broker MONGODB_URI mongodb://admin:admin@ds121686.mlab.com:21686/jameslim

cf start mongodb-service-broker

cf create-service-broker mongodb-service-broker-jl pivotal keepitsimple mongodb-service-broker-jl.cfapps.io --space-scoped

# cf push spring-music -p ./spring-music.jar -m 768M -n spring-music-jl

cf create-service MongoDB-jl standard mongo-service

cf bind-service spring-music mongo-service

cf restart spring-music

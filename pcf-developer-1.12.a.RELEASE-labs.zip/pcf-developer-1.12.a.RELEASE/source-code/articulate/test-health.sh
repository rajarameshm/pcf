#!/bin/sh
BASE_URL=https://$1 mvn verify

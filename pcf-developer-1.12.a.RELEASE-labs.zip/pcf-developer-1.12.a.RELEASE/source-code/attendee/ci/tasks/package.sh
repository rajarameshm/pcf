#!/bin/sh

set -e +x

cd attendee-service
./mvnw clean package
# attendee-service

## Courses using this application.

`Note`: When updating this application please make sure the corresponding instructions are updated within the following dependent courses. The instructions for these labs may not change but please review before pushing application to production with this [pipeline](http://concourse.enablement.pivotal.io/pipelines/attendee-service).

- [pivotal-cloud-foundry-developer](https://github.com/pivotal-education/pivotal-cloud-foundry-developer):
- [pivotal-cloud-foundry-administrator](https://github.com/pivotal-education/pivotal-cloud-foundry-administrator)
